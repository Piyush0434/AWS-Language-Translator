package com.example.lambdafunction;

class DialogAction {
    private String type;

    public DialogAction() {}

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
