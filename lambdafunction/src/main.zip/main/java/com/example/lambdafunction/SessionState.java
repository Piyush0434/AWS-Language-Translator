package com.example.lambdafunction;

class SessionState {
    private DialogAction dialogAction;
    private String sessionId;
    private Intent intent;

    public SessionState() {}

    public DialogAction getDialogAction() { return dialogAction; }
    public void setDialogAction(DialogAction dialogAction) { this.dialogAction = dialogAction; }
    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }
    public Intent getIntent() { return intent; }
    public void setIntent(Intent intent) { this.intent = intent; }
}
