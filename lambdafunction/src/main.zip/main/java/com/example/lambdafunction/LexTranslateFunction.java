package com.example.lambdafunction;

import com.LambdaInnerResponse;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.translate.AmazonTranslate;
import com.amazonaws.services.translate.AmazonTranslateClientBuilder;
import com.amazonaws.services.translate.model.TranslateTextRequest;
import com.amazonaws.services.translate.model.TranslateTextResult;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LexTranslateFunction implements RequestHandler<Map<String, Object>, LambdaInnerResponse> {

    @Override
    public LambdaInnerResponse handleRequest(Map<String, Object> input, Context context) {
        try {
            // Debug: Print received input
            System.out.println("Received input: " + input);

            // Extract session state safely
            Map<String, Object> sessionState = (Map<String, Object>) input.get("sessionState");
            if (sessionState == null) {
                return buildLexResponse("Error: Missing sessionState.", "default-session", null);
            }

            // Extract sessionId safely
            String sessionId = getSessionId(sessionState);

            // Extract intent safely
            Map<String, Object> intent = (Map<String, Object>) sessionState.get("intent");
            if (intent == null) {
                return buildLexResponse("Error: Missing intent in sessionState.", sessionId, null);
            }

            // Extract slots safely
            Map<String, Object> slots = (Map<String, Object>) intent.get("slots");
            if (slots == null) {
                return buildLexResponse("Error: Missing slots in intent.", sessionId, intent);
            }

            // Debug: Print slots for verification
            System.out.println("Slots content: " + slots);

            // Extract values safely
            String userText = extractSlotValue(slots, "CustomText");
            String targetLanguage = mapLanguage(extractSlotValue(slots, "Language"));

            // Validate extracted values
            if (userText == null || targetLanguage == null) {
                return buildLexResponse("Invalid input. Please try again.", sessionId, intent);
            }

            // AWS Translate logic
            AmazonTranslate translate = AmazonTranslateClientBuilder.defaultClient();
            TranslateTextRequest request = new TranslateTextRequest()
                    .withText(userText)
                    .withSourceLanguageCode("en")
                    .withTargetLanguageCode(targetLanguage);

            TranslateTextResult result = translate.translateText(request);
            String translatedText = result.getTranslatedText();

            // Return structured response to Lex
            return buildLexResponse("Translated text: " + translatedText, sessionId, intent);

        } catch (Exception e) {
            // Handle errors while ensuring `intent` is always passed
            return buildLexResponse("An error occurred: " + e.getMessage(), "default-session", null);
        }
    }

    // Extract slot value from the incoming slots map
    private String extractSlotValue(Map<String, Object> slots, String slotName) {
        if (slots == null || !slots.containsKey(slotName)) return null;

        Object slot = slots.get(slotName);
        if (slot instanceof Map) {
            Map<String, Object> valueMap = (Map<String, Object>) ((Map<String, Object>) slot).get("value");
            if (valueMap != null && valueMap.containsKey("interpretedValue")) {
                return (String) valueMap.get("interpretedValue");
            }
        }
        return null;
    }

    // Map user-selected language to AWS Translate codes
    private String mapLanguage(String language) {
        if (language == null) return null;
        switch (language.toLowerCase()) {
            case "french": return "fr";
            case "spanish": return "es";
            case "german": return "de";
            default: return null;
        }
    }

    // Extract sessionId safely & prevent LinkedHashMap cast errors
    private String getSessionId(Map<String, Object> sessionState) {
        if (sessionState == null) return "default-session";  // Fallback

        Object sessionIdObj = sessionState.get("sessionId");
        if (sessionIdObj instanceof String) {
            return (String) sessionIdObj;
        }

        return "default-session"; // Fallback if sessionId is missing
    }

    // Build Lex response with sessionId and intent
    private LambdaInnerResponse buildLexResponse(String message, String sessionId, Map<String, Object> intent) {
        LambdaInnerResponse response = new LambdaInnerResponse();
        SessionState sessionState = new SessionState();
        DialogAction dialogAction = new DialogAction();
        dialogAction.setType("Close");
        sessionState.setDialogAction(dialogAction);
        sessionState.setSessionId(sessionId);

        // Ensure intent has a name
        if (intent == null || !intent.containsKey("name")) {
            intent = new HashMap<>();
            intent.put("name", "TranslateIntent");  // Default name
            intent.put("slots", new HashMap<>());   // Ensure slots exist
        }

        sessionState.setIntent(new Intent(intent.get("name").toString()));

        response.setSessionState(sessionState);

        Message messageObj = new Message();
        messageObj.setContent(message);
        messageObj.setContentType("PlainText");

        response.setMessages(List.of(messageObj));

        // Debugging: Print response to verify
        System.out.println("Response sent to Lex: " + response);

        return response;
    }
}
